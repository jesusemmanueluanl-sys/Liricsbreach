# Lyrics Bridge (app Android + mod de Fabric)

Muestra en Minecraft (Zalith Launcher) la letra sincronizada de lo que suena en YouTube, YouTube Music, Spotify, etc. en el mismo celular.

Cómo funciona: la app Android lee la sesión multimedia del sistema, busca la letra en lrclib.net y publica la línea actual en http://127.0.0.1:8765/now. El mod consulta esa dirección y dibuja la línea en el HUD.

## 1. Compilar la app (sin PC, con GitHub desde el celular)
1. Crea un repositorio en GitHub y sube TODO el contenido de esta carpeta (incluida la carpeta oculta .github).
2. Pestaña Actions -> "Build APK" -> Run workflow (también corre solo al subir).
3. Cuando termine, abre la ejecución y descarga el artefacto "lyricsbridge-apk". Descomprime e instala app-debug.apk.

(Con Android Studio: abre la carpeta android-app y pulsa Run.)

## 2. Configurar la app en el celular
1. Abre Lyrics Bridge -> "Dar acceso a notificaciones" -> activa Lyrics Bridge.
   Si Android dice "ajuste restringido": Ajustes -> Apps -> Lyrics Bridge -> menú de 3 puntos -> "Permitir ajustes restringidos", y vuelve a intentar.
2. "Quitar optimización de batería" -> permitir (para que no la cierre mientras juegas).
3. Pon una canción en YouTube o Spotify y toca "Probar": debe salir JSON con título y "line".

## 3. Compilar el mod
No incluyo build.gradle porque las versiones de Loom/Fabric API para tu versión de Minecraft cambian seguido. Usa la plantilla oficial:
1. Entra a https://fabricmc.net/develop/template, elige tu versión de Minecraft, mod id "lyricsbridge", y descarga el zip.
2. Copia en ese proyecto:
   - fabric-mod/src/client/java/com/lyricsbridge/mod/LyricsBridgeClient.java  -> src/client/java/com/lyricsbridge/mod/
     (si desactivaste "split sources" en la plantilla, ponlo en src/main/java/...)
   - fabric-mod/src/main/resources/fabric.mod.json -> reemplaza el de la plantilla.
   Borra la clase de ejemplo de la plantilla y su entrada en fabric.mod.json / mixins si no la necesitas.
3. Sube el proyecto a GitHub; la plantilla ya trae un workflow que compila el .jar (Actions -> artefacto).
4. Pon el .jar en la carpeta mods de Zalith junto con Fabric API.

## Ajustes
- Letra adelantada/atrasada: en los argumentos JVM de Zalith agrega -Dlyricsbridge.url=http://127.0.0.1:8765/now?offset=300 (ms; negativo para atrasar).
- Puerto: Bridge.DEFAULT_PORT en Bridge.kt (y la misma URL en el mod).

## Notas
- No compilé ni probé nada de esto (sin SDK ni Minecraft en mi entorno). Es posible que haya que corregir algún import o firma, sobre todo del mod en tu versión exacta de Minecraft: pásame el error de compilación y lo arreglo.
- Solo el servidor local en 127.0.0.1: otras apps del mismo celular podrían leer qué suena.
- Código original, sin usar nada del mod "Show the lyrics" (licencia All Rights Reserved).
